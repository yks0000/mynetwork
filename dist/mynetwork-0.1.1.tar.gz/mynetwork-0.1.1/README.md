install dep: poetry install
update dep: poetry update
add dep: poetry add click requests
show dep: poetry show
remove dep: poetry remove pendulum

build: poetry build

cache list: poetry cache list

VEnv: poetry env info