# MyNetwork CLI

## Usage
```bash
Usage: mynetwork [OPTIONS] COMMAND [ARGS]...

Options:
  --help  Show this message and exit.

Commands:
  ip
  speed  Speed Group
```

## Speed Group:

```bash
Usage: mynetwork speed [OPTIONS] COMMAND [ARGS]...

  Speed Group

Options:
  --help  Show this message and exit.

Commands:
  download
  upload
```